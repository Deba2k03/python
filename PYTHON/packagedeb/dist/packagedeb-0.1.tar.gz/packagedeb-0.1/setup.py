from setuptools import setup
setup(name="packagedeb",
version="0.1",
description="this is debashish package",
long_description="this a very very long description",
author="Deb",
# author_email="sahudeba03@gmail.com",
packages=['packagedeb'],
install_requires=[])