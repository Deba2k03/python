def func(number):
    print("this is a func")
    return number

